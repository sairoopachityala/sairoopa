package com.shopping.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shopping.controller.DaoUser;

/**
 * Servlet implementation class cart
 */
@WebServlet("/cart")
public class cart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public cart() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("post()");
		//doGet(request, response);
		String userId=request.getParameter("userId");
		String password=request.getParameter("password");
		DaoUser Daouser=new DaoUser();
		if(Daouser.isvalidcontroller(userId,password)) {
			RequestDispatcher dispatcher=request.getRequestDispatcher("home1.html");
					dispatcher.forward(request,response);
		}
	else
	{
		PrintWriter out=response.getWriter();
		out.print("Invalid credentials");
		RequestDispatcher dispatcher=request.getRequestDispatcher("signin.html");
		dispatcher.include(request,response);
		
	}

}
	}

