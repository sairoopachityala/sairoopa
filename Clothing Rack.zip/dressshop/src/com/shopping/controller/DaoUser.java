package com.shopping.controller;

public class DaoUser {
	public boolean isvalidcontroller(String userId, String password)
	{
		if(userId.equals("NIIT") && password.equals("NIIT@123"))
		{
			return true;
		}
		else
		{
		return false;
		}
		}
		}