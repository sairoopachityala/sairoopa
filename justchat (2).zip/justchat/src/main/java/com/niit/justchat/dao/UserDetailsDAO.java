package com.niit.justchat.dao;

import java.util.List;

import com.niit.justchat.model.UserDetails;

public interface UserDetailsDAO {
        
//	public List<UserDetails> list();
	
	public void saveOrUpdate(UserDetails userdetails);
	
//	public UserDetails getUserByName(String username);
	
//	public UserDetails getUserById(int userid);
	
}

