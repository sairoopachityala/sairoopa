package com.user.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
 
import first.UserDAO;

@Controller

public class UserController {
	
	
UserDAO userDAO = new UserDAO();
	@RequestMapping("/isValidUser")
	public ModelAndView showMessage(@RequestParam (value="name") String name,@RequestParam(value="password") String password) {
	System.out.println(name+password);	
	
	String message;
	
	if(userDAO.isValidUser(name,password))
	{
		message="Valid Credentials";
	}
	else
	{
		message="InValid Credentials";
	}
     ModelAndView mv = new ModelAndView("succes");
		//message="ok";
	mv.addObject("message",message);
	mv.addObject("name",name);
	//System.out.println("\nContr end");
	return mv;
	
	}

}