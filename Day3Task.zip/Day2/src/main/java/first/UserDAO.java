package first;
import org.springframework.stereotype.Repository;

@Repository

public class UserDAO {
	public boolean isValidUser(String userID,String password){
		if(userID.equals("NIIT") && password.equals("NIIT@123") )
		{
			return true;
			}
		else
		{
			return false;
			
		}
	}
}